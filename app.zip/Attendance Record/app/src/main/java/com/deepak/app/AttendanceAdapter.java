package com.deepak.app;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.TextView;
import android.view.View;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
//import com.google.firebase.database.core.view.View;
import java.util.List;
public class AttendanceAdapter extends RecyclerView.Adapter<AttendanceAdapter.ViewHolder>{
       List<AttendanceModel>attendanceList;
    public AttendanceAdapter(List<AttendanceModel>attendanceList){
        this.attendanceList=attendanceList;
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType){
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.item_attendance,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            AttendanceModel model =attendanceList.get(position);
            holder.tvDate.setText(model.getDate());
            holder.tvStatus.setText(model.getStatus());
            if("P".equals(model.getStatus())){
                holder.tvStatus.setTextColor(Color.GREEN);
            }
            else{
                holder.tvStatus.setTextColor(Color.RED);
            }
    }
    @Override
    public int getItemCount(){
        return attendanceList.size();
    }
    public static class ViewHolder extends RecyclerView.ViewHolder{
        TextView tvDate,tvStatus;
        public ViewHolder(@NonNull View itemView){
            super(itemView);
            tvDate=itemView.findViewById(R.id.tvdate);
            tvStatus=itemView.findViewById(R.id.tvstatus);
        }
    }
}
