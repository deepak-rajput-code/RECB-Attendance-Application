package com.deepak.app;

import static android.app.ProgressDialog.show;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class faculty extends AppCompatActivity {
    ImageButton back_btn_faculty;
    Button new_user, mark_attendance;
    RadioGroup select_class;
    TextView tv_faculty_name;
    DatabaseReference reference;

    EditText date_from_pop, subject_code_from_pop;
    TextView rollno_pop, status_pop;
    Button absent, present, previous, next, final_submit;
    Dialog dialog;
    ArrayList<String> roll_list = new ArrayList<>();
    ArrayList<String>status_list=new ArrayList<>();
    HashMap<String, String> attendancemap = new HashMap<>();
    int index = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_faculty);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.faculty), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);

//            select_class = findViewById(R.id.class_group);
//            int class_selected = select_class.getCheckedRadioButtonId();
//            RadioButton class_take = findViewById(class_selected);
//            String class_choose = class_take.getText().toString();


            back_btn_faculty = findViewById(R.id.faculty_back_btn);
            back_btn_faculty.setOnClickListener(view -> {
                Intent intent = new Intent(faculty.this, MainActivity.class);
                startActivity(intent);
            });

            new_user = findViewById(R.id.new_register_btn);
            new_user.setOnClickListener(view -> {
                DatabaseReference addref = FirebaseDatabase.getInstance().getReference("form_registration");
         reference=FirebaseDatabase.getInstance().getReference("form_registration");
                addref.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        for (DataSnapshot usersnap : snapshot.getChildren()) {
                            if (usersnap.exists()) {
//                                usersnap.getRef().child("mark_attendance").child("BCS401").child("15-07-2005").setValue("A");
//                                usersnap.getRef().child("mark_attendance").child("BCS402").child("15-07-2005").setValue("A");
//                                usersnap.getRef().child("mark_attendance").child("BCS403").child("15-07-2005").setValue("A");
//                                usersnap.getRef().child("mark_attendance").child("BAS403").child("15-07-2005").setValue("A");
//                                usersnap.getRef().child("mark_attendance").child("BCC402").child("15-07-2005").setValue("A");
//                                usersnap.getRef().child("mark_attendance").child("BVE401").child("15-07-2005").setValue("A");
                                usersnap.getRef().child("mark_attendance").removeValue();
//                            usersnap.getRef().child("mark_attendance").child("BCS402");
//                            usersnap.getRef().child("mark_attendance").child("BCS403");
//                            usersnap.getRef().child("mark_attendance").child("BAS403");
//                            usersnap.getRef().child("mark_attendance").child("BCC402");
//                            usersnap.getRef().child("mark_attendance").child("BVE401");
//                            usersnap.getRef().child("attendance").child("maths_iv").setValue("BAS403");
//                            usersnap.getRef().child("attendance").child("python_programming").setValue("BCC402");
////                            usersnap.getRef().child("attendance").child("UHV").setValue("BVE401");
                            }
                        }
                        Toast.makeText(faculty.this, "add data", Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
//        String faculty_name="xyz";
//        String faculty_username="faculty@recb";
//        String faculty_password="1234";
//       form_registration new_faculty=new form_registration(faculty_name,faculty_username,faculty_password);
//       reference.child(faculty_username).setValue(new_faculty);
//       Toast.makeText(Attendance.this,"data add",Toast.LENGTH_SHORT).show();

            });

            tv_faculty_name = findViewById(R.id.faculty_name_fire);
            String username_faculty = getIntent().getStringExtra("username_faculty");
            reference = FirebaseDatabase.getInstance().getReference("form_registration");
            reference.child(username_faculty).addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    String faculty_name = snapshot.child("faculty_name").getValue(String.class);
                    tv_faculty_name.setText(faculty_name);
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                }
            });

            mark_attendance = findViewById(R.id.mark_attendance_btn);

            mark_attendance.setOnClickListener(v1 -> {
                Dialog dialog = new Dialog(faculty.this);
                dialog.setContentView(R.layout.attendance_pop);
                dialog.setCancelable(false);
                dialog.show();

                date_from_pop = dialog.findViewById(R.id.date_pop);
                subject_code_from_pop = dialog.findViewById(R.id.subject_code_pop);
                rollno_pop = dialog.findViewById(R.id.rollno_pop);
                status_pop = dialog.findViewById(R.id.status_pop);

                absent = dialog.findViewById(R.id.Absent_btn);
                present = dialog.findViewById(R.id.Present_btn);
                previous = dialog.findViewById(R.id.previous_btn);
                next = dialog.findViewById(R.id.next_btn);
                final_submit = dialog.findViewById(R.id.final_submit);

//                if (class_choose.equals("IT 2nd")) {
                         loadStudent();
//                }

            });
            return insets;
        });

    }

    private void loadStudent(){
        DatabaseReference ref=FirebaseDatabase.getInstance().getReference("form_registration");
        ref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
//                roll_list.clear();
                for(DataSnapshot snap:snapshot.getChildren()){
                    roll_list.add(snap.getKey());
                }
                rollno_pop.setText(roll_list.get(index));
                 for(int i=0;i<roll_list.size();i++){
                     status_list.add("status");
                 }
                startAttendance();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
    private void startAttendance(){
        present.setOnClickListener(v -> {
            attendancemap.put(roll_list.get(index),"P");
           status_pop.setText("P");
           status_pop.setTextColor(Color.GREEN);
           status_list.set(index,"P");
        });
        absent.setOnClickListener(v -> {
            attendancemap.put(roll_list.get(index),"A");
            status_pop.setText("A");
            status_pop.setTextColor(Color.RED);
            status_list.set(index,"A");
        });
        next.setOnClickListener(v -> {

             if(status_list.get(index).equals("status")){
                 Toast.makeText(v.getContext(),"please Mark Attendance",Toast.LENGTH_SHORT).show();
                 return;
             }
            if(index<roll_list.size()-1){
                index++;
                rollno_pop.setText(roll_list.get(index));
            }
            load_status();
        });
        previous.setOnClickListener(v -> {
            if(index>0){
                index--;
                rollno_pop.setText(roll_list.get(index));
            }
            load_status();
        });
        final_submit.setOnClickListener(v -> {
            save_attendance();
//            dialog.dismiss();
        });
    }

    private void load_status(){
        String status_load=status_list.get(index);
        if(status_load.equals("P")){
            status_pop.setText("P");
            status_pop.setTextColor(Color.GREEN);
        }
        else if(status_load.equals("A")){
            status_pop.setText("A");
            status_pop.setTextColor(Color.RED);
        }
        else {
            status_pop.setText("");
            status_pop.setTextColor(Color.GRAY);
        }
    }
    private void save_attendance(){
        String date=date_from_pop.getText().toString().trim();
        String subject_code_fd=subject_code_from_pop.getText().toString().trim();
        DatabaseReference save_ref=FirebaseDatabase.getInstance().getReference("form_registration");
        Map<String,Object>finalMap=new HashMap<>();
        for(Map.Entry<String,String>entry:attendancemap.entrySet()){
//            save_ref.child(entry.getKey()).child("mark_attendance").child(subject_code_fd).child(date).setValue(entry.getValue());
            finalMap.put(entry.getKey()+"/mark_attendance/"+subject_code_fd+"/"+date,entry.getValue());
        }
        save_ref.updateChildren(finalMap).addOnSuccessListener(unused -> {
            Toast.makeText(this,"Attendance Saved Successfully",Toast.LENGTH_SHORT).show();
            dialog.dismiss();
        });

//        Toast.makeText(this,"Attendance Saved Successfully",Toast.LENGTH_SHORT).show();
    }
}