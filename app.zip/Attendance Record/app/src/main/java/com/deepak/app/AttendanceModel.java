package com.deepak.app;

public class AttendanceModel {
    private String date;
    private  String status;
    public AttendanceModel(){}
    public AttendanceModel(String date,String status){
        this.date=date;
        this.status=status;
    }
    public String getDate(){
        return date;
    }

    public String getStatus(){
        return status;
    }
}
