package com.deepak.app;

public class form_registration {
    public String name, roll_no, branch, username_reg, password_reg;
      public String faculty_name,faculty_username,faculty_password;

    public form_registration(String name, String roll_no, String branch, String username_reg, String password_reg) {
        this.name = name;
        this.roll_no = roll_no;
        this.branch = branch;
        this.username_reg = username_reg;
        this.password_reg = password_reg;

    }

    public form_registration(String faculty_name, String faculty_username, String faculty_Password) {
     this.faculty_name=faculty_name;
     this.faculty_username=faculty_username;
     this.faculty_password=faculty_Password;
    }
}

