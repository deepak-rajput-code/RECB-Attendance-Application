package com.deepak.app;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class Attendance extends AppCompatActivity {
   ImageButton back_btn_att;
Button addbtn;

TextView tvsubject_name;
TextView tvsubject_code;
DatabaseReference reference,databaseReference;
    List<AttendanceModel>attendanceList;
    AttendanceAdapter adapter;
    RecyclerView recyclerView;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_attendance);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.attend_page), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);

                back_btn_att=findViewById(R.id.img_backbtn_att);
                back_btn_att.setOnClickListener(v1 -> {
                   finish();
                });

          tvsubject_name=findViewById(R.id.sub_name_att);
          tvsubject_code=findViewById(R.id.sub_code_att);

              Intent intent=getIntent();
              String subject_name_get=intent.getStringExtra("sub_pass");
              String sub_name_firebase=intent.getStringExtra("sub_pass_att");
            String subjectcoderec=intent.getStringExtra("sub_code_rec");


              String user_info=getIntent().getStringExtra("user_data");
              reference=FirebaseDatabase.getInstance().getReference("form_registration");

              reference.child(user_info).addListenerForSingleValueEvent(new ValueEventListener() {
                  @Override
                  public void onDataChange(@NonNull DataSnapshot snapshot) {
                      if(snapshot.exists()){
                          String sub_code_fire=snapshot.child("attendance").child(sub_name_firebase).getValue(String.class);
                          tvsubject_code.setText(sub_code_fire);

                          String sub_name_fire=snapshot.child("subject").child(subject_name_get).getValue(String.class);
                          tvsubject_name.setText(sub_name_fire);
                      }
                  }
                  @Override
                  public void onCancelled(@NonNull DatabaseError error) {

                  }
              });



            recyclerView=findViewById(R.id.rv_attendance);
            recyclerView.setLayoutManager(new LinearLayoutManager(this));
            attendanceList=new ArrayList<>();
            adapter=new AttendanceAdapter(attendanceList);
            recyclerView.setAdapter(adapter);
            databaseReference=FirebaseDatabase.getInstance().getReference("form_registration")
                    .child(user_info).child("mark_attendance").child(subjectcoderec);
            loadAttendance();
            return insets;
        });
    }
    private void loadAttendance(){
        attendanceList.clear();
        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                for(DataSnapshot dataSnapshot:snapshot.getChildren()){
                   String date=dataSnapshot.getKey();
                   String status=dataSnapshot.getValue(String.class);
                   attendanceList.add(new AttendanceModel(date,status));
                }
                adapter.notifyDataSetChanged();
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });
    }
}