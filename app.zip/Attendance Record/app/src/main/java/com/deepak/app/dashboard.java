package com.deepak.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class dashboard extends AppCompatActivity {
    TextView tvName, tvBranch, tvRoll,tvsem,tvos,tvtafl,tvoopsjava,tvmaths4,tvpython,tvuhv;
    TextView tvs1_code,tvs2_code,tvs3_code,tvs4_code,tvs5_code,tvs6_code;
    DatabaseReference reference;
    ImageButton backbtn;
    Button os,taf,oops_java,maths4,python,uhv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_dashboard);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.profileaccount), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);

             backbtn=findViewById(R.id.backbtn);
             backbtn.setOnClickListener(view->{
                 Intent intent=new Intent(dashboard.this, MainActivity.class);
                 startActivity(intent);
             });

             tvName=findViewById(R.id.name_fire);
             tvRoll=findViewById(R.id.roll_fire);
             tvBranch=findViewById(R.id.branch_fire);
             tvsem=findViewById(R.id.sem_fire);

             tvos=findViewById(R.id.OS);
             tvtafl=findViewById(R.id.tafl);
             tvoopsjava=findViewById(R.id.oops_java);
             tvmaths4=findViewById(R.id.maths_iv);
             tvpython=findViewById(R.id.python);
             tvuhv=findViewById(R.id.uhv);

             tvs1_code=findViewById(R.id.s1_code);
            tvs2_code=findViewById(R.id.s2_code);
            tvs3_code=findViewById(R.id.s3_code);
            tvs4_code=findViewById(R.id.s4_code);
            tvs5_code=findViewById(R.id.s5_code);
            tvs6_code=findViewById(R.id.s6_code);


             String username_user =getIntent().getStringExtra("username_reg");
             reference=FirebaseDatabase.getInstance().getReference("form_registration");
             reference.child(username_user).addListenerForSingleValueEvent(new ValueEventListener() {
                 @Override
                 public void onDataChange(@NonNull DataSnapshot snapshot) {
                     if(snapshot.exists()){
                         String u_name=snapshot.child("name").getValue(String.class);
                         String u_roll=snapshot.child("roll_no").getValue(String.class);
                         String u_branch=snapshot.child("branch").getValue(String.class);
                         String u_sem=snapshot.child("semester").getValue(String.class);

                         String u_s1=snapshot.child("subject").child("s1_os").getValue(String.class);
                         String u_s2=snapshot.child("subject").child("s2_tafl").getValue(String.class);
                         String u_s3=snapshot.child("subject").child("s3_oops_java").getValue(String.class);
                         String u_s4=snapshot.child("subject").child("s4_maths4").getValue(String.class);
                         String u_s5=snapshot.child("subject").child("s5_python_programming").getValue(String.class);
                         String u_s6=snapshot.child("subject").child("s6_uhv").getValue(String.class);

                         String u_s1_code=snapshot.child("attendance").child("operating_system").getValue(String.class);
                         String u_s2_code=snapshot.child("attendance").child("tafl").getValue(String.class);
                         String u_s3_code=snapshot.child("attendance").child("oops_java").getValue(String.class);
                         String u_s4_code=snapshot.child("attendance").child("maths_iv").getValue(String.class);
                         String u_s5_code=snapshot.child("attendance").child("python_programming").getValue(String.class);
                         String u_s6_code=snapshot.child("attendance").child("UHV").getValue(String.class);

                         tvName.setText(u_name);
                         tvRoll.setText(u_roll);
                         tvBranch.setText(u_branch);
                         tvsem.setText(u_sem);

                         tvos.setText(u_s1);
                         tvtafl.setText(u_s2);
                         tvoopsjava.setText(u_s3);
                         tvmaths4.setText(u_s4);
                         tvpython.setText(u_s5);
                         tvuhv.setText(u_s6);

                         tvs1_code.setText(u_s1_code);
                         tvs2_code.setText(u_s2_code);
                         tvs3_code.setText(u_s3_code);
                         tvs4_code.setText(u_s4_code);
                         tvs5_code.setText(u_s5_code);
                         tvs6_code.setText(u_s6_code);
                     }
                     else {
                         Toast.makeText(dashboard.this, "User data not found", Toast.LENGTH_SHORT).show();
                     }
                 }

                 @Override
                 public void onCancelled(@NonNull DatabaseError error) {
                     Toast.makeText(dashboard.this, "Database error", Toast.LENGTH_SHORT).show();
                 }
             });



            os=findViewById(R.id.os_attendance);
            taf=findViewById(R.id.tafl_attendance);
            oops_java=findViewById(R.id.oop_java_attendance);
            maths4=findViewById(R.id.maths_attendance);
            python=findViewById(R.id.python_attendance);
            uhv=findViewById(R.id.uhv_attendance);


            os.setOnClickListener(v1 -> {
                String subject_name_das="s1_os";
                String subject_name_pass="operating_system";
                String subject_code_rec="BCS401";
                Intent intent =new Intent(dashboard.this,Attendance.class);
                intent.putExtra("sub_pass",subject_name_das);
                intent.putExtra("sub_pass_att",subject_name_pass);
                 intent.putExtra("sub_code_rec",subject_code_rec);
                intent.putExtra("user_data",username_user);
                startActivity(intent);
            });

            taf.setOnClickListener(v1 -> {
                String subject_name_das="s2_tafl";
                String subject_name_pass="tafl";
                String subject_code_rec="BCS402";
                Intent intent =new Intent(dashboard.this,Attendance.class);
                intent.putExtra("sub_pass",subject_name_das);
                intent.putExtra("sub_pass_att",subject_name_pass);
                intent.putExtra("sub_code_rec",subject_code_rec);
                intent.putExtra("user_data",username_user);
                startActivity(intent);
            });
            oops_java.setOnClickListener(v1 -> {
                String subject_name_das="s3_oops_java";
                String subject_name_pass="oops_java";
                String subject_code_rec="BCS403";
                Intent intent =new Intent(dashboard.this,Attendance.class);
                intent.putExtra("sub_pass",subject_name_das);
                intent.putExtra("sub_pass_att",subject_name_pass);
                intent.putExtra("sub_code_rec",subject_code_rec);
                intent.putExtra("user_data",username_user);
                startActivity(intent);
            });
            maths4.setOnClickListener(v1 -> {
                String subject_name_das="s4_maths4";
                String subject_name_pass="maths_iv";
                String subject_code_rec="BAS403";
                Intent intent =new Intent(dashboard.this,Attendance.class);
                intent.putExtra("sub_pass",subject_name_das);
                intent.putExtra("sub_pass_att",subject_name_pass);
                intent.putExtra("sub_code_rec",subject_code_rec);
                intent.putExtra("user_data",username_user);
                startActivity(intent);
            });
            python.setOnClickListener(v1 -> {
                String subject_name_das="s5_python_programming";
                String subject_name_pass="python_programming";
                String subject_code_rec="BCC402";
                Intent intent =new Intent(dashboard.this,Attendance.class);
                intent.putExtra("sub_pass",subject_name_das);
                intent.putExtra("sub_pass_att",subject_name_pass);
                intent.putExtra("sub_code_rec",subject_code_rec);
                intent.putExtra("user_data",username_user);
                startActivity(intent);
            });
            uhv.setOnClickListener(v1 -> {
                String subject_name_das="s6_uhv";
                String subject_name_pass="UHV";
                String subject_code_rec="BVE401";
                Intent intent =new Intent(dashboard.this,Attendance.class);
                intent.putExtra("sub_pass",subject_name_das);
                intent.putExtra("sub_pass_att",subject_name_pass);
                intent.putExtra("sub_code_rec",subject_code_rec);
                intent.putExtra("user_data",username_user);
                startActivity(intent);
            });


            return insets;
        });
    }
}