package com.deepak.app;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

public class register extends AppCompatActivity {
 EditText name;
 EditText roll_no;
 RadioGroup radio_group_branch;
 EditText username;
 EditText password;
 EditText developer_code;
 Button registration_btn;

 FirebaseDatabase database;
 DatabaseReference reference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
//        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.registrationform), (v, insets) -> {
//            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
//            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);

            name=findViewById(R.id.name);
          roll_no=findViewById(R.id.roll_no);
          radio_group_branch=findViewById(R.id.radio_group);
          username=findViewById(R.id.username_reg);
           password=findViewById(R.id.password_reg);
            developer_code=findViewById(R.id.developer_code);
            registration_btn=findViewById(R.id.registration_btn);

           reference=FirebaseDatabase.getInstance().getReference("form_registration");
            registration_btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    register_user();
                }
            });

//            return insets;
//        });
    }
    private void register_user(){
        String name1=name.getText().toString().trim();
        String student_roll=roll_no.getText().toString().trim();
        String student_username=username.getText().toString().trim();
        String student_password=password.getText().toString().trim();
        String student_developer_code= developer_code.getText().toString().trim();
        int selected_branch=radio_group_branch.getCheckedRadioButtonId();



               if (name1.isEmpty() || student_roll.isEmpty() || student_username.isEmpty() || student_password.isEmpty() || selected_branch == -1
               || student_developer_code.isEmpty()) {
                   Toast.makeText(this, "please fill all fields", Toast.LENGTH_SHORT).show();
                   return;
               }

                       int dev_code=Integer.parseInt(student_developer_code);
                        if(dev_code!=4565471){
                            Toast.makeText(this,"incorrect developer code",Toast.LENGTH_SHORT).show();
                           return;
                        }

                RadioButton selectBranch=findViewById(selected_branch);
                String branch=selectBranch.getText().toString();
                form_registration user= new form_registration(name1,student_roll,branch,student_username,student_password);

                reference.child(student_username).setValue(user);
                Toast.makeText(this, "Registration Successful", Toast.LENGTH_SHORT).show();

        name.setText("");
        roll_no.setText("");
        username.setText("");
        password.setText("");
        developer_code.setText("");
        radio_group_branch.clearCheck();

        Intent intent = new Intent(register.this, MainActivity.class);
        startActivity(intent);

    }
}