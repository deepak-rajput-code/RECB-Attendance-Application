package com.deepak.app;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.content.Intent;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


public class MainActivity extends AppCompatActivity {
    EditText username, password;
    Button loginbtn;
    Button registerbtn;

   DatabaseReference reference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.loginpage), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);

            username = findViewById(R.id.username);
            password = findViewById(R.id.password);
            loginbtn = findViewById(R.id.loginbtn);
              reference= FirebaseDatabase.getInstance().getReference("form_registration");

              loginbtn.setOnClickListener(v1 -> login_user());


            registerbtn=findViewById(R.id.registerbtn);
            registerbtn.setOnClickListener(view ->{
                  Intent intent = new Intent(MainActivity.this, register.class);
                  startActivity(intent);
                 finish();
            });

            return insets;
        });
    }
    private void login_user(){
        String username_1=username.getText().toString().trim();
        String password_1=password.getText().toString().trim();
         if(username_1.isEmpty()||password_1.isEmpty()){
             Toast.makeText(this,"All field required",Toast.LENGTH_SHORT).show();
             return;
         }
         reference.child(username_1).addListenerForSingleValueEvent(new ValueEventListener() {
             @Override
             public void onDataChange(@NonNull DataSnapshot snapshot) {
                 if(snapshot.exists()){
                     String dbpassword=snapshot.child("password_reg").getValue(String.class);
                     String facultydbpass=snapshot.child("faculty_password").getValue(String.class);
                     if(password_1.equals(dbpassword)||password_1.equals(facultydbpass)){
                         String f_p="1234";
                          if(password_1.equals(f_p)){
                              Intent intent=new Intent(MainActivity.this,faculty.class);
                              intent.putExtra("username_faculty",username_1);
                              startActivity(intent);
                          }
                          else {
                              Intent intent = new Intent(MainActivity.this, dashboard.class);
                              intent.putExtra("username_reg", username_1);
                              startActivity(intent);
                          }
                     }
                     else{
                         Toast.makeText(MainActivity.this,"wrong password",Toast.LENGTH_SHORT).show();
                     }
                 }
                 else {
                     Toast.makeText(MainActivity.this,"user not found",Toast.LENGTH_SHORT).show();
                 }
             }

             @Override
             public void onCancelled(@NonNull DatabaseError error) {
               Toast.makeText(MainActivity.this,"Database error",Toast.LENGTH_SHORT).show();
             }
         });
    }
}

